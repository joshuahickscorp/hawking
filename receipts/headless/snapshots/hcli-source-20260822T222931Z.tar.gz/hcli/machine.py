from __future__ import annotations

import json
import os
import platform
import subprocess
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


def _run_cmd(cmd: List[str]) -> Optional[str]:
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=5,
        )
        if proc.returncode == 0:
            return proc.stdout.strip()
    except Exception:
        pass
    return None


def _parse_vm_stat() -> Dict[str, int]:
    out = _run_cmd(["vm_stat"])
    if not out:
        return {}
    result = {}
    for line in out.splitlines():
        if ":" in line:
            key, _, val = line.partition(":")
            val = val.strip().rstrip(".")
            if val.isdigit():
                result[key.strip()] = int(val)
    return result


def _get_page_size() -> int:
    out = _run_cmd(["sysctl", "-n", "vm.pagesize"])
    if out and out.isdigit():
        return int(out)
    return 16384


@dataclass
class MachineProbe:
    physical_memory_bytes: int = 0
    page_size: int = 16384
    vm_stat: Dict[str, int] = field(default_factory=dict)
    pressure: str = "unknown"
    swap_bytes: int = 0

    def probe(self) -> "MachineProbe":
        self.page_size = _get_page_size()

        mem_out = _run_cmd(["sysctl", "-n", "hw.memsize"])
        if mem_out and mem_out.isdigit():
            self.physical_memory_bytes = int(mem_out)

        self.vm_stat = _parse_vm_stat()

        pressure_out = _run_cmd(["memory_pressure", "-Q"])
        if pressure_out:
            if "low" in pressure_out.lower():
                self.pressure = "low"
            elif "normal" in pressure_out.lower():
                self.pressure = "normal"
            elif "high" in pressure_out.lower():
                self.pressure = "high"
            else:
                self.pressure = "unknown"

        swap_out = _run_cmd(["sysctl", "-n", "vm.swapusage"])
        if swap_out:
            for part in swap_out.split():
                if part.startswith("used="):
                    val = part[5:].replace(".", "").replace("K", "000").replace("M", "000000").replace("G", "000000000")
                    if val.isdigit():
                        self.swap_bytes = int(val)
                    break

        return self


class MemGate:
    def __init__(self, reserve_bytes: Optional[int] = None):
        self.reserve_bytes = reserve_bytes

    def calculate_reserve(self, physical_memory_bytes: int) -> int:
        if self.reserve_bytes is not None:
            return self.reserve_bytes
        return max(12 * 1024**3, int(physical_memory_bytes * 0.15))

    def available_estimate(self, probe: MachineProbe) -> int:
        reserve = self.calculate_reserve(probe.physical_memory_bytes)
        return max(0, probe.physical_memory_bytes - reserve)

    def is_safe(self, probe: MachineProbe) -> bool:
        if probe.pressure == "high":
            return False
        if probe.swap_bytes > 1024**3:
            return False
        return True


@dataclass
class MachineGenome:
    path: Path
    data: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            try:
                self.data = json.loads(self.path.read_text())
            except Exception:
                self.data = {}

    def save(self) -> None:
        self.path.write_text(json.dumps(self.data, indent=2))

    def get_profile(self, key: str) -> Optional[Dict[str, Any]]:
        return self.data.get(key)

    def set_profile(self, key: str, profile: Dict[str, Any]) -> None:
        self.data[key] = profile


def get_machine_genome_path() -> Path:
    base = Path(os.environ.get("HCLI_HOME", Path.home() / ".local" / "share" / "hcli"))
    return base / "machine-genome.json"