from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

WORKUNIT_STATUSES = ("pending", "ready", "running", "completed", "failed")
DEFAULT_RETRY_BUDGET = 3


@dataclass
class WorkUnit:
    id: str
    role: str
    description: str
    dependencies: List[str] = field(default_factory=list)
    status: str = "pending"
    assigned_runtime: Optional[int] = None
    attempts: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "role": self.role,
            "description": self.description,
            "dependencies": self.dependencies,
            "status": self.status,
            "assigned_runtime": self.assigned_runtime,
            "attempts": self.attempts,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkUnit":
        return cls(
            id=data["id"],
            role=data["role"],
            description=data["description"],
            dependencies=data.get("dependencies", []),
            status=data.get("status", "pending"),
            assigned_runtime=data.get("assigned_runtime"),
            attempts=data.get("attempts", 0),
        )


def transition_status(wu: WorkUnit, new_status: str) -> bool:
    valid = {
        "pending": {"ready"},
        "ready": {"running"},
        "running": {"completed", "failed"},
        "failed": {"ready"},
        "completed": set(),
    }
    if new_status in valid.get(wu.status, set()):
        wu.status = new_status
        return True
    return False


def is_ready(wu: WorkUnit, all_units: Dict[str, WorkUnit]) -> bool:
    if wu.status not in ("pending", "failed"):
        return False
    if wu.status == "failed" and wu.attempts >= DEFAULT_RETRY_BUDGET:
        return False
    for dep_id in wu.dependencies:
        dep = all_units.get(dep_id)
        if dep is None or dep.status != "completed":
            return False
    return True


def identify_ready(units: Dict[str, WorkUnit]) -> List[WorkUnit]:
    ready = []
    for wu in units.values():
        if is_ready(wu, units):
            transition_status(wu, "ready")
            ready.append(wu)
    return ready


def assign_ready(ready_units: List[WorkUnit], runtime_count: int) -> List[tuple]:
    assignments = []
    used = set()
    for wu in ready_units:
        if wu.status != "ready":
            continue
        for idx in range(runtime_count):
            if idx not in used:
                transition_status(wu, "running")
                wu.assigned_runtime = idx
                wu.attempts += 1
                used.add(idx)
                assignments.append((wu, idx))
                break
        else:
            break
    return assignments
