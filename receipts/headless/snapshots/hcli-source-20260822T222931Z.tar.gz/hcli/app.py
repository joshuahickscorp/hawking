from __future__ import annotations

import os
import sys
from typing import Optional

from .controller import Controller
from .tui import TUI
from .events import EventBus
from .workspace import Workspace
from .models import ModelRegistry


class App:
    def __init__(self, workspace: str, runtime_count: int = 1, model: Optional[str] = None, debug: bool = False):
        self.workspace = workspace
        self.runtime_count = runtime_count
        self.model = model
        self.debug = debug
        self.ws = Workspace(workspace)
        self.registry = ModelRegistry()
        self.bus = EventBus()
        self.controller = Controller(
            workspace=self.ws,
            runtime_count=runtime_count,
            model=model,
            bus=self.bus,
            registry=self.registry,
        )

    def run(self, prompt: Optional[str] = None) -> int:
        if prompt:
            return self._run_headless(prompt)
        return self._run_interactive()

    def _run_headless(self, prompt: str) -> int:
        self.bus.emit("session_started", {"mode": "headless"})
        try:
            result = self.controller.execute(prompt)

            if isinstance(result, int):
                return result

            if not isinstance(result, dict):
                print(str(result))
                return 0

            content = str(result.get("content") or "")
            error = str(result.get("error") or "")

            if content:
                print(content)
            elif error:
                print(error, file=sys.stderr)

            if result.get("cancelled"):
                return 130

            if error or result.get("rolled_back"):
                return 1

            return 0
        finally:
            self.controller.shutdown()

    def _run_interactive(self) -> int:
        model_name = self.controller.model_name or "local"
        tui = TUI(
            event_bus=self.bus,
            workspace=self.ws.root,
            model_name=model_name,
            runtime_count=self.runtime_count,
        )
        self.bus.emit("session_started", {"mode": "interactive"})
        try:
            return tui.run(on_input=self._handle_input)
        finally:
            self.controller.shutdown()

    def _handle_input(self, text: str):
        self.bus.emit("user_message", {"text": text})
        if text.startswith("/"):
            return self.controller.handle_command(text)
        return self.controller.execute(text)
