from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

from .events import Event, EventBus
from .goal import GoalCompiler
from .workspace import Workspace


_REASONING_KEYS = {
    "reasoning",
    "reasoning_content",
    "hidden_reasoning",
    "chain_of_thought",
    "thinking",
}

_PATH_TOKEN_RE = re.compile(
    r"""(?:
        (?P<quoted>["'`])(?P<qpath>[^"'`\n]+?)(?P=quoted)
        |
        (?P<path>
            (?:\./|\../)?
            [A-Za-z0-9_.@+~/-]+
            \.
            (?:py|md|txt|json|toml|yaml|yml|js|ts|tsx|jsx|rs|c|cc|cpp|h|hpp|sh)
        )
    )""",
    re.VERBOSE,
)


class EngineError(RuntimeError):
    pass


class Engine:
    """Native HCLI execution boundary.

    This is intentionally standalone.  It does not import HAIDER or the
    bootstrap tool bridge.

    The current bridge supports:
      * deterministic named-file evidence
      * GoalCompiler metadata
      * local llama-server structured responses
      * read-only answers
      * structured multi-file mutation
      * complete transaction rollback
      * deterministic Python validation
      * bounded admitted test execution
      * durable receipts
      * cancellation checkpoints
      * reasoning-field suppression

    More advanced WorkUnit scheduling is layered on top of this boundary.
    """

    MAX_EVIDENCE_FILES = 16
    MAX_EVIDENCE_CHARS_PER_FILE = 24000
    MAX_TOTAL_EVIDENCE_CHARS = 120000
    MAX_OPERATIONS = 20

    def __init__(
        self,
        workspace: Workspace,
        model_client: Any = None,
        event_bus: Optional[EventBus] = None,
        runtime_provider: Optional[Callable[[], Any]] = None,
        runtime_state_provider: Optional[Callable[[], Any]] = None,
        runtime_count: int = 1,
        model_name: Optional[str] = None,
    ) -> None:
        self.workspace = workspace
        self.root = Path(workspace.root).expanduser().resolve()

        self.model_client = model_client
        self.event_bus = event_bus or EventBus()
        self.runtime_provider = runtime_provider
        self.runtime_state_provider = runtime_state_provider
        self.runtime_count = max(1, int(runtime_count))
        self.model_name = model_name or "local"

        self.goal_compiler = GoalCompiler()

        self._cancelled = False
        self._active_goal_id: Optional[str] = None
        self.last_result: Optional[Dict[str, Any]] = None

    # -----------------------------------------------------------------
    # Lifecycle
    # -----------------------------------------------------------------

    @property
    def active(self) -> bool:
        return self._active_goal_id is not None

    def cancel(self) -> None:
        self._cancelled = True

    def _emit(
        self,
        event_type: str,
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.event_bus.emit(
            Event(event_type, data or {})
        )

    def _cancel_result(
        self,
        goal_id: str,
    ) -> Dict[str, Any]:
        result = {
            "kind": "error",
            "content": "",
            "operations": [],
            "tests": [],
            "cancelled": True,
            "error": "Goal cancelled",
            "goal_id": goal_id,
            "status": "cancelled",
        }

        self._write_receipt(
            goal_id=goal_id,
            goal="",
            result=result,
            evidence=[],
            validation=None,
            rolled_back=False,
        )

        self._emit(
            "goal_completed",
            {
                "goal_id": goal_id,
                "status": "cancelled",
            },
        )

        self._emit(
            "final_response",
            {
                "content": "Goal cancelled.",
                "status": "cancelled",
            },
        )

        return result

    # -----------------------------------------------------------------
    # Primary execution
    # -----------------------------------------------------------------

    def execute(
        self,
        prompt: str,
    ) -> Dict[str, Any]:
        prompt = (prompt or "").strip()

        if not prompt:
            return {
                "kind": "answer",
                "content": "",
                "operations": [],
                "tests": [],
                "status": "completed",
            }

        goal_id = str(uuid.uuid4())
        self._active_goal_id = goal_id

        started = datetime.now(timezone.utc)

        self._emit(
            "goal_started",
            {
                "goal_id": goal_id,
                "text": prompt,
            },
        )

        try:
            if self._cancelled:
                return self._cancel_result(goal_id)

            evidence = self._gather_evidence(prompt)

            try:
                compiled = self.goal_compiler.compile(prompt)
            except Exception:
                compiled = {}

            self._emit(
                "goal_compiled",
                {
                    "goal_id": goal_id,
                    "evidence_files": [
                        item["path"]
                        for item in evidence
                    ],
                    "workunits": self._compiled_workunit_count(
                        compiled
                    ),
                },
            )

            if self._cancelled:
                return self._cancel_result(goal_id)

            raw = self._call_model(
                prompt,
                evidence,
                compiled,
            )

            result = self._sanitize_result(
                raw
            )

            if self._cancelled:
                return self._cancel_result(goal_id)

            kind = result.get("kind")

            if kind == "answer":
                result["status"] = "completed"
                result["goal_id"] = goal_id

                receipt = self._write_receipt(
                    goal_id=goal_id,
                    goal=prompt,
                    result=result,
                    evidence=evidence,
                    validation={
                        "ok": True,
                        "kind": "read_only",
                    },
                    rolled_back=False,
                    started=started,
                )

                result["receipt"] = receipt

                self._emit(
                    "goal_completed",
                    {
                        "goal_id": goal_id,
                        "status": "completed",
                    },
                )

                self._emit(
                    "final_response",
                    {
                        "goal_id": goal_id,
                        "content": result.get(
                            "content",
                            "",
                        ),
                        "status": "completed",
                    },
                )

                self.last_result = result
                return result

            if kind != "mutation":
                raise EngineError(
                    f"Unsupported model result kind: {kind!r}"
                )

            operations = result.get(
                "operations",
                [],
            )

            if not isinstance(operations, list):
                raise EngineError(
                    "operations must be a list"
                )

            if not 1 <= len(operations) <= self.MAX_OPERATIONS:
                raise EngineError(
                    "mutation operation count must be "
                    f"1..{self.MAX_OPERATIONS}"
                )

            tests = result.get(
                "tests",
                [],
            )

            if not isinstance(tests, list):
                tests = []

            self._emit(
                "mutation_prepared",
                {
                    "goal_id": goal_id,
                    "operations": len(operations),
                },
            )

            paths = self._operation_paths(
                operations
            )

            snapshot = self._snapshot(
                paths
            )

            rolled_back = False
            validation: Optional[Dict[str, Any]] = None

            try:
                self._apply_operations(
                    operations
                )

                self._emit(
                    "mutation_applied",
                    {
                        "goal_id": goal_id,
                        "paths": [
                            str(p.relative_to(self.root))
                            for p in paths
                        ],
                    },
                )

                if self._cancelled:
                    raise EngineError(
                        "Goal cancelled before validation"
                    )

                self._emit(
                    "validation_started",
                    {
                        "goal_id": goal_id,
                    },
                )

                validation = self._validate(
                    paths,
                    tests,
                )

                ok = (
                    bool(validation)
                    if isinstance(validation, bool)
                    else bool(
                        validation.get("ok")
                        if isinstance(
                            validation,
                            dict,
                        )
                        else False
                    )
                )

                if not ok:
                    raise EngineError(
                        "Deterministic validation failed"
                    )

                self._emit(
                    "validation_passed",
                    {
                        "goal_id": goal_id,
                        "validation": validation,
                    },
                )

            except BaseException as exc:
                self._restore(
                    snapshot
                )

                rolled_back = True

                self._emit(
                    "rollback",
                    {
                        "goal_id": goal_id,
                        "reason": str(exc),
                    },
                )

                if validation is not None:
                    self._emit(
                        "validation_failed",
                        {
                            "goal_id": goal_id,
                            "validation": validation,
                        },
                    )

                result["rolled_back"] = True
                result["error"] = str(exc)
                result["status"] = (
                    "cancelled"
                    if self._cancelled
                    else "failed"
                )
                result["goal_id"] = goal_id

                receipt = self._write_receipt(
                    goal_id=goal_id,
                    goal=prompt,
                    result=result,
                    evidence=evidence,
                    validation=validation,
                    rolled_back=True,
                    started=started,
                )

                result["receipt"] = receipt

                self._emit(
                    "goal_completed",
                    {
                        "goal_id": goal_id,
                        "status": result["status"],
                    },
                )

                self._emit(
                    "final_response",
                    {
                        "goal_id": goal_id,
                        "content": (
                            result.get("content")
                            or result.get("error")
                            or "Goal failed"
                        ),
                        "status": result["status"],
                    },
                )

                self.last_result = result
                return result

            result["rolled_back"] = False
            result["status"] = "completed"
            result["goal_id"] = goal_id

            receipt = self._write_receipt(
                goal_id=goal_id,
                goal=prompt,
                result=result,
                evidence=evidence,
                validation=validation,
                rolled_back=False,
                started=started,
            )

            result["receipt"] = receipt

            self._emit(
                "goal_completed",
                {
                    "goal_id": goal_id,
                    "status": "completed",
                },
            )

            self._emit(
                "final_response",
                {
                    "goal_id": goal_id,
                    "content": result.get(
                        "content",
                        "",
                    ),
                    "status": "completed",
                },
            )

            self.last_result = result
            return result

        except BaseException as exc:
            result = {
                "kind": "error",
                "content": "",
                "operations": [],
                "tests": [],
                "error": str(exc),
                "goal_id": goal_id,
                "status": "failed",
            }

            self._write_receipt(
                goal_id=goal_id,
                goal=prompt,
                result=result,
                evidence=[],
                validation=None,
                rolled_back=False,
                started=started,
            )

            self._emit(
                "error",
                {
                    "goal_id": goal_id,
                    "message": str(exc),
                },
            )

            self._emit(
                "goal_completed",
                {
                    "goal_id": goal_id,
                    "status": "failed",
                },
            )

            self.last_result = result
            return result

        finally:
            self._active_goal_id = None
            self._cancelled = False

    # -----------------------------------------------------------------
    # Goal / evidence
    # -----------------------------------------------------------------

    def _compiled_workunit_count(
        self,
        compiled: Any,
    ) -> int:
        if not isinstance(compiled, dict):
            return 0

        dag = compiled.get("workunits")

        units = getattr(
            dag,
            "units",
            None,
        )

        if isinstance(units, dict):
            return len(units)

        return 0

    def _extract_path_tokens(
        self,
        text: str,
    ) -> List[str]:
        candidates: List[str] = []

        for match in _PATH_TOKEN_RE.finditer(
            text or ""
        ):
            value = (
                match.group("qpath")
                or match.group("path")
                or ""
            ).strip()

            if not value:
                continue

            if value.startswith(
                (
                    "http://",
                    "https://",
                )
            ):
                continue

            candidates.append(value)

        result: List[str] = []
        seen = set()

        for value in candidates:
            value = value.rstrip(
                ".,:;)]}"
            )

            if value not in seen:
                seen.add(value)
                result.append(value)

        return result

    def _is_instruction_document(
        self,
        path: Path,
        prompt: str,
    ) -> bool:
        """Return True only when nested file-reference expansion is justified.

        Ordinary source/readme/docs are evidence, not implicit manifests.

        Nested expansion is reserved for explicit task/spec/mission documents
        so a request such as "read README.md" cannot recursively ingest an
        entire repository merely because README names source files.
        """
        try:
            rel = path.relative_to(self.root)
        except ValueError:
            return False

        upper_name = path.name.upper()

        instruction_markers = (
            "TASK",
            "MISSION",
            "SPEC",
            "PLAN",
            "GOAL",
            "ULTRAGOAL",
            "ACCEPTANCE",
            "FULFILL",
            "SELFHOST",
            "HANDOFF",
        )

        explicit_instruction_verb = any(
            token in (prompt or "").lower()
            for token in (
                "execute ",
                "execute it",
                "follow ",
                "implement ",
                "fulfill ",
                "according to ",
                "use the instructions",
            )
        )

        under_control_dir = (
            len(rel.parts) > 0
            and rel.parts[0] in {
                ".haider",
                ".hcli",
            }
        )

        named_like_instruction = any(
            marker in upper_name
            for marker in instruction_markers
        )

        return bool(
            explicit_instruction_verb
            and (
                under_control_dir
                or named_like_instruction
            )
        )

    def _evidence_char_budget(self) -> int:
        """Conservative prompt-evidence budget derived from local context.

        This is intentionally approximate because HCLI must not require a
        tokenizer merely to admit deterministic evidence.

        Reserve:
          - requested generation tokens
          - 4096 tokens for system/user framing and estimation error

        Then assume ~3 UTF-8 text characters/token for conservative admission.
        """
        ctx_size = int(
            os.environ.get(
                "HCLI_CTX_SIZE",
                "32768",
            )
        )

        output_tokens = int(
            os.environ.get(
                "HCLI_MODEL_TOKENS",
                "6500",
            )
        )

        reserve_tokens = (
            output_tokens
            + 4096
        )

        usable_tokens = max(
            4096,
            ctx_size - reserve_tokens,
        )

        calculated = usable_tokens * 3

        explicit = os.environ.get(
            "HCLI_EVIDENCE_CHAR_BUDGET"
        )

        if explicit:
            try:
                return max(
                    4096,
                    int(explicit),
                )
            except ValueError:
                pass

        return max(
            16384,
            min(
                self.MAX_TOTAL_EVIDENCE_CHARS,
                calculated,
            ),
        )

    def _gather_evidence(
        self,
        prompt: str,
    ) -> List[Dict[str, Any]]:
        """Gather deterministic evidence without uncontrolled recursion."""
        queue = [
            (token, True)
            for token in self._extract_path_tokens(
                prompt
            )
        ]

        seen = set()
        evidence: List[Dict[str, Any]] = []

        total_chars = 0
        char_budget = self._evidence_char_budget()

        while (
            queue
            and len(evidence) < self.MAX_EVIDENCE_FILES
            and total_chars < char_budget
        ):
            token, explicit_from_prompt = queue.pop(0)

            try:
                path = self._safe_path(
                    token,
                    allow_missing=False,
                )
            except Exception:
                continue

            key = str(path)

            if key in seen:
                continue

            seen.add(key)

            if not path.is_file():
                continue

            remaining = (
                char_budget
                - total_chars
            )

            if remaining <= 0:
                break

            per_file_limit = min(
                self.MAX_EVIDENCE_CHARS_PER_FILE,
                remaining,
            )

            try:
                content = path.read_text(
                    encoding="utf-8",
                    errors="replace",
                )
            except Exception:
                continue

            content = content[
                :per_file_limit
            ]

            rel = str(
                path.relative_to(
                    self.root
                )
            )

            evidence.append(
                {
                    "path": rel,
                    "content": content,
                }
            )

            total_chars += len(content)

            # Only explicit task/spec/mission documents may expand nested
            # references. README.md, source code, documentation, etc. are
            # terminal evidence by default.
            if (
                explicit_from_prompt
                and self._is_instruction_document(
                    path,
                    prompt,
                )
            ):
                for nested in self._extract_path_tokens(
                    content
                ):
                    queue.append(
                        (
                            nested,
                            False,
                        )
                    )

        return evidence

    # -----------------------------------------------------------------
    # Local model
    # -----------------------------------------------------------------

    def _runtime_endpoint(
        self,
    ) -> Tuple[str, Dict[str, Any]]:
        if self.runtime_provider is None:
            raise EngineError(
                "No RuntimePool provider is configured"
            )

        pool = self.runtime_provider()

        runtimes = list(
            getattr(
                pool,
                "runtimes",
                [],
            )
        )

        if not runtimes:
            raise EngineError(
                "RuntimePool has no admitted runtimes"
            )

        runtime = runtimes[0]

        port = getattr(
            runtime,
            "port",
            None,
        )

        if port is None:
            raise EngineError(
                "Runtime has no port"
            )

        provenance = {
            "index": getattr(
                runtime,
                "index",
                0,
            ),
            "pid": getattr(
                runtime,
                "pid",
                None,
            ),
            "port": port,
        }

        return (
            f"http://127.0.0.1:{port}/v1/chat/completions",
            provenance,
        )

    def _call_model(
        self,
        prompt: str,
        evidence: Optional[List[Dict[str, Any]]] = None,
        compiled: Any = None,
    ) -> Dict[str, Any]:
        if self.model_client is not None:
            call = getattr(
                self.model_client,
                "complete",
                None,
            )

            if callable(call):
                return call(
                    prompt=prompt,
                    evidence=evidence or [],
                    compiled=compiled,
                )

        endpoint, provenance = self._runtime_endpoint()

        evidence_text = "\n\n".join(
            (
                f"===== {item['path']} =====\n"
                f"{item['content']}"
            )
            for item in (evidence or [])
        )

        system = """You are the native HCLI local engineering worker.

MODELS THINK.
TOOLS KNOW.
DISK STATE IS AUTHORITY.
CONTEXT IS A CACHE.

Return exactly one JSON object and nothing else.

For a read-only request:
{
  "kind": "answer",
  "content": "concise final answer",
  "operations": [],
  "tests": []
}

For a requested code/file change:
{
  "kind": "mutation",
  "content": "concise description of what changed",
  "operations": [
    {
      "op": "replace|create|replace_file|insert_before|insert_after|append",
      "path": "workspace/relative/path",
      "old_text": "exact anchor when required",
      "new_text": "new content"
    }
  ],
  "tests": ["optional safe workspace-relative Python test paths"]
}

Rules:
- maximum 20 operations
- paths are workspace-relative
- never modify .git/**
- never return shell commands as mutation authority
- use exact old_text anchors
- use create only for nonexistent files
- if asked only a question, do not mutate
- do not include reasoning_content, hidden reasoning, chain-of-thought, or <think>
"""

        user = (
            f"GOAL:\n{prompt}\n\n"
            f"DETERMINISTIC EVIDENCE:\n"
            f"{evidence_text or '(none)'}"
        )

        payload = {
            "model": self.model_name or "local",
            "messages": [
                {
                    "role": "system",
                    "content": system,
                },
                {
                    "role": "user",
                    "content": user,
                },
            ],
            "temperature": 0.15,
            "max_tokens": int(
                os.environ.get(
                    "HCLI_MODEL_TOKENS",
                    "6500",
                )
            ),
        }

        request = urllib.request.Request(
            endpoint,
            data=json.dumps(
                payload
            ).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
            },
            method="POST",
        )

        timeout = float(
            os.environ.get(
                "HCLI_MODEL_TIMEOUT",
                "1800",
            )
        )

        self._emit(
            "workunit_started",
            {
                "runtime": provenance,
                "role": "primary",
            },
        )

        try:
            with urllib.request.urlopen(
                request,
                timeout=timeout,
            ) as response:
                body = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(
                "utf-8",
                errors="replace",
            )

            raise EngineError(
                f"llama-server HTTP {exc.code}: "
                f"{detail[:1200]}"
            ) from exc
        except Exception as exc:
            raise EngineError(
                f"llama-server request failed: {exc}"
            ) from exc

        try:
            data = json.loads(
                body.decode(
                    "utf-8",
                    errors="replace",
                )
            )
        except Exception as exc:
            raise EngineError(
                "llama-server returned invalid JSON"
            ) from exc

        try:
            message = data["choices"][0]["message"]
        except Exception as exc:
            raise EngineError(
                "llama-server response missing choices[0].message"
            ) from exc

        content = message.get(
            "content",
            "",
        )

        parsed = self._extract_json_object(
            content
        )

        self._emit(
            "workunit_completed",
            {
                "runtime": provenance,
                "role": "primary",
            },
        )

        return parsed

    def _extract_json_object(
        self,
        content: Any,
    ) -> Dict[str, Any]:
        if isinstance(content, dict):
            return content

        text = str(
            content or ""
        ).strip()

        if text.startswith("```"):
            text = re.sub(
                r"^```(?:json)?\s*",
                "",
                text,
                flags=re.I,
            )

            text = re.sub(
                r"\s*```$",
                "",
                text,
            ).strip()

        try:
            parsed = json.loads(text)

            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass

        decoder = json.JSONDecoder()

        for index, char in enumerate(text):
            if char != "{":
                continue

            try:
                parsed, _ = decoder.raw_decode(
                    text[index:]
                )
            except Exception:
                continue

            if isinstance(parsed, dict):
                return parsed

        raise EngineError(
            "Model did not return a valid structured JSON object"
        )

    # -----------------------------------------------------------------
    # Result sanitization
    # -----------------------------------------------------------------

    def _strip_reasoning(
        self,
        value: Any,
    ) -> Any:
        if isinstance(value, dict):
            return {
                key: self._strip_reasoning(item)
                for key, item in value.items()
                if key.lower() not in _REASONING_KEYS
            }

        if isinstance(value, list):
            return [
                self._strip_reasoning(item)
                for item in value
            ]

        if isinstance(value, str):
            value = re.sub(
                r"<think>.*?</think>",
                "",
                value,
                flags=re.I | re.S,
            )

        return value

    def _sanitize_result(
        self,
        result: Any,
    ) -> Dict[str, Any]:
        if not isinstance(result, dict):
            raise EngineError(
                "Model result must be a JSON object"
            )

        result = self._strip_reasoning(
            result
        )

        kind = str(
            result.get(
                "kind",
                "",
            )
        ).strip().lower()

        if kind not in {
            "answer",
            "mutation",
        }:
            raise EngineError(
                "Model result kind must be answer or mutation"
            )

        content = str(
            result.get(
                "content",
                "",
            )
        )

        operations = result.get(
            "operations",
            [],
        )

        tests = result.get(
            "tests",
            [],
        )

        if not isinstance(operations, list):
            operations = []

        if not isinstance(tests, list):
            tests = []

        return {
            "kind": kind,
            "content": content,
            "operations": operations,
            "tests": [
                str(item)
                for item in tests
                if isinstance(
                    item,
                    (str, Path),
                )
            ],
        }

    # -----------------------------------------------------------------
    # Path authority
    # -----------------------------------------------------------------

    def _safe_path(
        self,
        raw_path: Any,
        allow_missing: bool = True,
    ) -> Path:
        text = str(
            raw_path or ""
        ).strip()

        if not text:
            raise EngineError(
                "empty mutation path"
            )

        candidate = Path(text).expanduser()

        if candidate.is_absolute():
            full = candidate
        else:
            full = self.root / candidate

        # Resolve the closest existing ancestor so a nonexistent destination
        # cannot use a symlink parent to escape the workspace.
        probe = full

        missing_parts: List[str] = []

        while not probe.exists():
            if probe == probe.parent:
                break

            missing_parts.append(
                probe.name
            )

            probe = probe.parent

        resolved_probe = probe.resolve()

        try:
            resolved_probe.relative_to(
                self.root
            )
        except ValueError as exc:
            raise EngineError(
                f"path escape rejected: {text}"
            ) from exc

        full = resolved_probe.joinpath(
            *reversed(
                missing_parts
            )
        )

        if full.exists():
            full = full.resolve()

            try:
                full.relative_to(
                    self.root
                )
            except ValueError as exc:
                raise EngineError(
                    f"symlink/path escape rejected: {text}"
                ) from exc

        rel = full.relative_to(
            self.root
        )

        if ".git" in rel.parts:
            raise EngineError(
                f".git mutation rejected: {text}"
            )

        if not allow_missing and not full.exists():
            raise EngineError(
                f"path does not exist: {text}"
            )

        return full

    # -----------------------------------------------------------------
    # Mutation transaction
    # -----------------------------------------------------------------

    def _operation_paths(
        self,
        operations: List[Dict[str, Any]],
    ) -> List[Path]:
        paths: List[Path] = []
        seen = set()

        for operation in operations:
            if not isinstance(operation, dict):
                raise EngineError(
                    "operation must be an object"
                )

            path = self._safe_path(
                operation.get("path"),
                allow_missing=True,
            )

            key = str(path)

            if key not in seen:
                seen.add(key)
                paths.append(path)

        return paths

    def _snapshot(
        self,
        paths: Iterable[Path],
    ) -> Dict[str, Optional[bytes]]:
        snapshot: Dict[str, Optional[bytes]] = {}

        for path in paths:
            key = str(path)

            if path.exists():
                if not path.is_file():
                    raise EngineError(
                        f"mutation target is not a file: {path}"
                    )

                snapshot[key] = path.read_bytes()
            else:
                snapshot[key] = None

        return snapshot

    def _restore(
        self,
        snapshot: Dict[str, Optional[bytes]],
    ) -> None:
        for raw_path, original in snapshot.items():
            path = Path(raw_path)

            if original is None:
                if path.exists() and path.is_file():
                    path.unlink()

                continue

            path.parent.mkdir(
                parents=True,
                exist_ok=True,
            )

            path.write_bytes(
                original
            )

    def _single_anchor(
        self,
        text: str,
        anchor: str,
        path: Path,
    ) -> None:
        count = text.count(
            anchor
        )

        if count != 1:
            raise EngineError(
                f"anchor must occur exactly once in "
                f"{path.relative_to(self.root)}; "
                f"found {count}"
            )

    def _apply_operations(
        self,
        operations: List[Dict[str, Any]],
    ) -> None:
        for index, operation in enumerate(
            operations
        ):
            op = str(
                operation.get(
                    "op",
                    "",
                )
            ).strip()

            path = self._safe_path(
                operation.get("path"),
                allow_missing=True,
            )

            old_text = str(
                operation.get(
                    "old_text",
                    "",
                )
            )

            new_text = str(
                operation.get(
                    "new_text",
                    "",
                )
            )

            if op == "create":
                if path.exists():
                    raise EngineError(
                        f"create target already exists: "
                        f"{path.relative_to(self.root)}"
                    )

                path.parent.mkdir(
                    parents=True,
                    exist_ok=True,
                )

                path.write_text(
                    new_text,
                    encoding="utf-8",
                )

                continue

            if op == "replace_file":
                if not path.exists():
                    raise EngineError(
                        f"replace_file target missing: "
                        f"{path.relative_to(self.root)}"
                    )

                path.write_text(
                    new_text,
                    encoding="utf-8",
                )

                continue

            if not path.exists():
                raise EngineError(
                    f"operation target missing: "
                    f"{path.relative_to(self.root)}"
                )

            text = path.read_text(
                encoding="utf-8",
                errors="strict",
            )

            if op == "replace":
                if not old_text:
                    raise EngineError(
                        "replace requires old_text"
                    )

                self._single_anchor(
                    text,
                    old_text,
                    path,
                )

                text = text.replace(
                    old_text,
                    new_text,
                    1,
                )

            elif op == "insert_before":
                if not old_text:
                    raise EngineError(
                        "insert_before requires old_text anchor"
                    )

                self._single_anchor(
                    text,
                    old_text,
                    path,
                )

                text = text.replace(
                    old_text,
                    new_text + old_text,
                    1,
                )

            elif op == "insert_after":
                if not old_text:
                    raise EngineError(
                        "insert_after requires old_text anchor"
                    )

                self._single_anchor(
                    text,
                    old_text,
                    path,
                )

                text = text.replace(
                    old_text,
                    old_text + new_text,
                    1,
                )

            elif op == "append":
                text += new_text

            else:
                raise EngineError(
                    f"unsupported mutation op "
                    f"{op!r} at index {index}"
                )

            path.write_text(
                text,
                encoding="utf-8",
            )

    # -----------------------------------------------------------------
    # Validation
    # -----------------------------------------------------------------

    def _safe_test_argv(
        self,
        raw: str,
    ) -> Optional[List[str]]:
        raw = str(
            raw or ""
        ).strip()

        if not raw:
            return None

        # Plain workspace-relative Python test path.
        if raw.endswith(".py") and " " not in raw:
            path = self._safe_path(
                raw,
                allow_missing=False,
            )

            return [
                sys.executable,
                str(path),
            ]

        try:
            argv = shlex.split(
                raw
            )
        except Exception:
            return None

        if len(argv) == 2 and argv[0] in {
            "python",
            "python3",
            sys.executable,
        }:
            path = self._safe_path(
                argv[1],
                allow_missing=False,
            )

            if path.suffix == ".py":
                return [
                    sys.executable,
                    str(path),
                ]

        return None

    def _validate(
        self,
        paths: Iterable[Path],
        tests: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        checks: List[Dict[str, Any]] = []
        ok = True

        for path in paths:
            if path.suffix != ".py":
                continue

            proc = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "py_compile",
                    str(path),
                ],
                cwd=str(self.root),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=120,
            )

            record = {
                "kind": "py_compile",
                "path": str(
                    path.relative_to(
                        self.root
                    )
                ),
                "exit_code": proc.returncode,
                "stdout": proc.stdout[-4000:],
                "stderr": proc.stderr[-4000:],
            }

            checks.append(record)

            if proc.returncode != 0:
                ok = False

        if ok:
            for raw in tests or []:
                argv = self._safe_test_argv(
                    raw
                )

                if argv is None:
                    checks.append(
                        {
                            "kind": "test",
                            "requested": raw,
                            "admitted": False,
                            "exit_code": None,
                        }
                    )

                    continue

                proc = subprocess.run(
                    argv,
                    cwd=str(self.root),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=300,
                    env={
                        **os.environ,
                        "PYTHONPATH": (
                            str(self.root)
                            + os.pathsep
                            + str(
                                self.root
                                / "tools"
                                / "haider"
                            )
                        ),
                    },
                )

                checks.append(
                    {
                        "kind": "test",
                        "requested": raw,
                        "admitted": True,
                        "exit_code": proc.returncode,
                        "stdout": proc.stdout[-8000:],
                        "stderr": proc.stderr[-8000:],
                    }
                )

                if proc.returncode != 0:
                    ok = False
                    break

        return {
            "ok": ok,
            "checks": checks,
        }

    # -----------------------------------------------------------------
    # Receipts
    # -----------------------------------------------------------------

    def _serialize_compiled(
        self,
        compiled: Any,
    ) -> Dict[str, Any]:
        if not isinstance(compiled, dict):
            return {}

        result: Dict[str, Any] = {}

        for key in (
            "invariants",
            "acceptance_criteria",
        ):
            value = compiled.get(key)

            if isinstance(value, list):
                result[key] = [
                    str(item)
                    for item in value
                ]

        dag = compiled.get(
            "workunits"
        )

        units = getattr(
            dag,
            "units",
            None,
        )

        if isinstance(units, dict):
            result["workunits"] = [
                (
                    unit.to_dict()
                    if hasattr(
                        unit,
                        "to_dict",
                    )
                    else {
                        "id": getattr(
                            unit,
                            "id",
                            None,
                        ),
                        "description": getattr(
                            unit,
                            "description",
                            "",
                        ),
                        "dependencies": list(
                            getattr(
                                unit,
                                "dependencies",
                                [],
                            )
                        ),
                    }
                )
                for unit in units.values()
            ]

        return result

    def _runtime_provenance(
        self,
    ) -> List[Dict[str, Any]]:
        if self.runtime_state_provider is None:
            return []

        try:
            pool = self.runtime_state_provider()
        except Exception:
            return []

        if pool is None:
            return []

        result = []

        for runtime in getattr(
            pool,
            "runtimes",
            [],
        ):
            result.append(
                {
                    "index": getattr(
                        runtime,
                        "index",
                        None,
                    ),
                    "pid": getattr(
                        runtime,
                        "pid",
                        None,
                    ),
                    "port": getattr(
                        runtime,
                        "port",
                        None,
                    ),
                    "active": getattr(
                        runtime,
                        "active",
                        None,
                    ),
                }
            )

        return result

    def _write_receipt(
        self,
        goal_id: str,
        goal: str,
        result: Dict[str, Any],
        evidence: List[Dict[str, Any]],
        validation: Any,
        rolled_back: bool,
        started: Optional[datetime] = None,
    ) -> str:
        started = started or datetime.now(
            timezone.utc
        )

        finished = datetime.now(
            timezone.utc
        )

        receipt_dir = (
            self.root
            / ".hcli"
            / "receipts"
        )

        receipt_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        path = receipt_dir / (
            f"{goal_id}.json"
        )

        receipt = {
            "goal_id": goal_id,
            "goal": goal,
            "model": self.model_name,
            "runtime_count": self.runtime_count,
            "runtime_provenance": self._runtime_provenance(),
            "evidence_files": [
                item["path"]
                for item in evidence
            ],
            "kind": result.get("kind"),
            "operations": result.get(
                "operations",
                [],
            ),
            "tests": result.get(
                "tests",
                [],
            ),
            "validation": validation,
            "rolled_back": bool(
                rolled_back
            ),
            "status": result.get(
                "status",
                "unknown",
            ),
            "timestamps": {
                "started_at": started.isoformat(),
                "finished_at": finished.isoformat(),
            },
        }

        path.write_text(
            json.dumps(
                self._strip_reasoning(
                    receipt
                ),
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )

        return str(path)
