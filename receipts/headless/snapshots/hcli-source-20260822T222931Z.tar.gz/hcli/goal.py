from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Dict, Iterable, List, Optional

from .workunit import WorkUnit


class WorkUnitDAG:
    """Small deterministic dependency graph for HCLI WorkUnits.

    The graph owns dependency readiness only.  Runtime assignment remains the
    Scheduler's responsibility.
    """

    def __init__(self) -> None:
        self.units: Dict[str, WorkUnit] = {}

    def add_unit(
        self,
        unit_id: str,
        description: str,
        dependencies: Optional[Iterable[str]] = None,
        *,
        role: str = "implementation",
    ) -> WorkUnit:
        if not unit_id:
            raise ValueError("WorkUnit id must not be empty")

        if unit_id in self.units:
            raise ValueError(f"Duplicate WorkUnit id: {unit_id}")

        deps = list(dependencies or [])

        if unit_id in deps:
            raise ValueError("WorkUnit cannot depend on itself")

        wu = WorkUnit(
            id=unit_id,
            role=role,
            description=description,
            dependencies=deps,
        )

        self.units[unit_id] = wu

        return wu

    def mark_completed(self, unit_id: str) -> None:
        wu = self.units[unit_id]
        wu.status = "completed"
        wu.assigned_runtime = None

    def mark_failed(self, unit_id: str) -> None:
        wu = self.units[unit_id]
        wu.status = "failed"
        wu.assigned_runtime = None

    def get_ready_units(self) -> List[WorkUnit]:
        ready: List[WorkUnit] = []

        for wu in self.units.values():
            if wu.status not in ("pending", "ready"):
                continue

            deps_complete = all(
                dep_id in self.units
                and self.units[dep_id].status == "completed"
                for dep_id in wu.dependencies
            )

            if deps_complete:
                ready.append(wu)

        return ready

    def to_dict(self) -> Dict[str, Any]:
        return {
            unit_id: wu.to_dict()
            for unit_id, wu in self.units.items()
        }


class GoalCompiler:
    """Compile a durable natural-language goal into focused deterministic IR.

    This compiler intentionally performs inexpensive structural extraction.
    Semantic model planning can enrich the resulting DAG later, but workers
    should not need the full durable goal merely to receive one bounded
    WorkUnit.
    """

    _FILE_RE = re.compile(
        r"(?<![A-Za-z0-9_.-])"
        r"((?:[A-Za-z0-9_.-]+/)*"
        r"[A-Za-z0-9_.-]+\."
        r"(?:py|pyi|js|jsx|ts|tsx|md|json|yaml|yml|toml|rs|go|txt))"
    )

    _INVARIANT_MARKERS = (
        "do not",
        "don't",
        "must",
        "must not",
        "never",
        "only",
        "without",
        "preserve",
        "required",
    )

    _ACCEPTANCE_MARKERS = (
        "test",
        "tests",
        "pass",
        "validate",
        "validation",
        "acceptance",
        "works",
        "working",
    )

    def _sentences(self, text: str) -> List[str]:
        pieces = re.split(
            r"(?<=[.!?])\s+|\n+",
            text.strip(),
        )

        return [
            piece.strip()
            for piece in pieces
            if piece.strip()
        ]

    def _referenced_files(self, goal_text: str) -> List[str]:
        return list(
            dict.fromkeys(
                match.rstrip(".,:;)")
                for match in self._FILE_RE.findall(goal_text)
            )
        )

    def compile(self, goal_text: str) -> Dict[str, Any]:
        text = (goal_text or "").strip()

        if not text:
            raise ValueError("Goal text must not be empty")

        sentences = self._sentences(text)

        invariants = [
            sentence
            for sentence in sentences
            if any(
                marker in sentence.lower()
                for marker in self._INVARIANT_MARKERS
            )
        ]

        acceptance = [
            sentence
            for sentence in sentences
            if any(
                marker in sentence.lower()
                for marker in self._ACCEPTANCE_MARKERS
            )
        ]

        if not acceptance:
            acceptance = [
                "Requested behavior is implemented and validated."
            ]

        files = self._referenced_files(text)

        primary = None

        for sentence in sentences:
            lower = sentence.lower()

            if any(
                marker in lower
                for marker in self._INVARIANT_MARKERS
            ):
                continue

            primary = sentence
            break

        if primary is None:
            primary = sentences[0]

        if len(primary) > 240:
            primary = primary[:237].rstrip() + "..."

        dag = WorkUnitDAG()

        implementation_description = primary

        if files:
            implementation_description += (
                " Relevant files: "
                + ", ".join(files[:6])
            )

        dag.add_unit(
            "implement",
            implementation_description,
            [],
            role="implementation",
        )

        dag.add_unit(
            "validate",
            "Validate the implementation against the active acceptance criteria.",
            ["implement"],
            role="validation",
        )

        return {
            "goal": text,
            "goal_summary": primary,
            "invariants": invariants,
            "acceptance_criteria": acceptance,
            "referenced_files": files,
            "workunits": dag,
        }

    def build_focused_context(
        self,
        workunit: WorkUnit,
        compiled_goal: Dict[str, Any],
    ) -> str:
        sections = [
            f"WORKUNIT: {workunit.id}",
            f"OBJECTIVE: {workunit.description}",
        ]

        invariants = list(
            compiled_goal.get("invariants", [])
        )[:4]

        if invariants:
            sections.append(
                "INVARIANTS:\n- "
                + "\n- ".join(invariants)
            )

        acceptance = list(
            compiled_goal.get(
                "acceptance_criteria",
                [],
            )
        )[:4]

        if acceptance:
            sections.append(
                "ACCEPTANCE:\n- "
                + "\n- ".join(acceptance)
            )

        files = list(
            compiled_goal.get(
                "referenced_files",
                [],
            )
        )[:8]

        if files:
            sections.append(
                "FILES:\n- "
                + "\n- ".join(files)
            )

        # This is deliberately a focused slice, not the complete durable goal.
        focused = "\n\n".join(sections)

        # Keep deterministic focused context bounded even when an invariant
        # sentence itself is unexpectedly enormous.
        if len(focused) > 1200:
            focused = focused[:1197].rstrip() + "..."

        return focused
