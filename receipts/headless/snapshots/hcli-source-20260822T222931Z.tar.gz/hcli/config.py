from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional


class Config:
    def __init__(self, workspace: str):
        self.workspace = workspace
        self.global_path = os.path.expanduser("~/.config/hcli/config.json")
        self.project_path = os.path.join(workspace, ".hcli", "config.json")

    def load(self) -> Dict[str, Any]:
        cfg: Dict[str, Any] = {}
        if os.path.isfile(self.global_path):
            with open(self.global_path) as f:
                cfg.update(json.load(f))
        if os.path.isfile(self.project_path):
            with open(self.project_path) as f:
                cfg.update(json.load(f))
        return cfg

    def save_project(self, data: Dict[str, Any]):
        os.makedirs(os.path.dirname(self.project_path), exist_ok=True)
        tmp = self.project_path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, self.project_path)
