from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class SteerEvent:
    id: str
    text: str
    session_id: str
    timestamp: float
    applied: bool = False
    applied_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "text": self.text,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "applied": self.applied,
            "applied_at": self.applied_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SteerEvent":
        return cls(
            id=data["id"],
            text=data["text"],
            session_id=data["session_id"],
            timestamp=data["timestamp"],
            applied=data.get("applied", False),
            applied_at=data.get("applied_at"),
        )


class SteeringQueue:
    def __init__(self, workspace: str, session_id: str):
        self.workspace = workspace
        self.session_id = session_id
        self._dir = os.path.join(workspace, ".hcli", "steering")
        os.makedirs(self._dir, exist_ok=True)
        self._path = os.path.join(self._dir, f"{session_id}.json")
        self._events: List[SteerEvent] = []
        self._load()

    def _load(self):
        if os.path.isfile(self._path):
            try:
                with open(self._path) as f:
                    data = json.load(f)
                self._events = [SteerEvent.from_dict(e) for e in data]
            except Exception:
                self._events = []

    def _save(self):
        tmp = self._path + ".tmp"
        with open(tmp, "w") as f:
            json.dump([e.to_dict() for e in self._events], f, indent=2)
        os.replace(tmp, self._path)

    def enqueue(self, text: str) -> SteerEvent:
        event = SteerEvent(
            id=str(uuid.uuid4()),
            text=text,
            session_id=self.session_id,
            timestamp=time.time(),
        )
        self._events.append(event)
        self._save()
        return event

    def pending(self) -> List[SteerEvent]:
        return [e for e in self._events if not e.applied]

    def apply_pending(self) -> List[SteerEvent]:
        applied = []
        for e in self._events:
            if not e.applied:
                e.applied = True
                e.applied_at = time.time()
                applied.append(e)
        if applied:
            self._save()
        return applied

    def clear_applied(self):
        self._events = [e for e in self._events if not e.applied]
        self._save()

    def all(self) -> List[SteerEvent]:
        return list(self._events)