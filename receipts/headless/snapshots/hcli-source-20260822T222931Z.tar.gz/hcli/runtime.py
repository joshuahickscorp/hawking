from __future__ import annotations

import concurrent.futures
import os
import shutil
import socket
import subprocess
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import List, Optional


def allocate_port() -> int:
    with socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM,
    ) as sock:
        sock.bind(
            ("127.0.0.1", 0)
        )

        return int(
            sock.getsockname()[1]
        )


@dataclass
class Runtime:
    index: int
    pid: Optional[int] = None
    port: Optional[int] = None
    model: str = ""
    process: Optional[subprocess.Popen] = None
    active: bool = False

    def stop(self) -> None:
        proc = self.process

        if proc is not None and proc.poll() is None:
            proc.terminate()

            try:
                proc.wait(
                    timeout=5
                )
            except subprocess.TimeoutExpired:
                proc.kill()

                try:
                    proc.wait(
                        timeout=5
                    )
                except Exception:
                    pass

        self.pid = None
        self.active = False
        self.process = None


class RuntimePool:
    """Physically independent local llama-server runtime pool."""

    def __init__(
        self,
        model_path: str,
        requested_n: int = 1,
    ) -> None:
        self.model_path = os.path.realpath(
            os.path.expanduser(
                model_path
            )
        )

        self.requested_n = int(
            requested_n
        )

        self.admitted_n = 0
        self.runtimes: List[Runtime] = []

    def _admit(
        self,
        n: int,
    ) -> int:
        return max(
            1,
            min(
                int(n),
                int(
                    os.environ.get(
                        "HCLI_MAX_RUNTIMES",
                        "8",
                    )
                ),
            ),
        )

    def _server_binary(
        self,
    ) -> str:
        explicit = os.environ.get(
            "HCLI_LLAMA_SERVER"
        )

        if explicit:
            return explicit

        binary = shutil.which(
            "llama-server"
        )

        if not binary:
            raise RuntimeError(
                "llama-server not found on PATH"
            )

        return binary

    def _command(
        self,
        port: int,
    ) -> List[str]:
        ctx_size = int(
            os.environ.get(
                "HCLI_CTX_SIZE",
                "32768",
            )
        )

        return [
            self._server_binary(),
            "--model",
            self.model_path,
            "--port",
            str(port),
            "--host",
            "127.0.0.1",
            "--ctx-size",
            str(ctx_size),
        ]

    def start(self) -> None:
        # Warm-pool reuse.
        if (
            self.runtimes
            and all(
                runtime.active
                and runtime.process is not None
                and runtime.process.poll() is None
                for runtime in self.runtimes
            )
        ):
            return

        self.stop()

        if not os.path.isfile(
            self.model_path
        ):
            raise FileNotFoundError(
                self.model_path
            )

        self.admitted_n = self._admit(
            self.requested_n
        )

        started: List[Runtime] = []

        try:
            # Spawn each physical process first so model loading overlaps.
            for index in range(
                self.admitted_n
            ):
                port = allocate_port()

                proc = subprocess.Popen(
                    self._command(port),
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                    start_new_session=True,
                )

                runtime = Runtime(
                    index=index,
                    pid=proc.pid,
                    port=port,
                    model=self.model_path,
                    process=proc,
                    active=True,
                )

                started.append(
                    runtime
                )

            self.runtimes = started

            timeout = float(
                os.environ.get(
                    "HCLI_READY_TIMEOUT",
                    "300",
                )
            )

            with concurrent.futures.ThreadPoolExecutor(
                max_workers=len(
                    self.runtimes
                )
            ) as executor:
                futures = [
                    executor.submit(
                        self._wait_ready,
                        runtime,
                        timeout,
                    )
                    for runtime in self.runtimes
                ]

                for future in futures:
                    future.result()

        except BaseException:
            self.stop()
            raise

    def _wait_ready(
        self,
        runtime: Runtime,
        timeout: float,
    ) -> None:
        assert runtime.port is not None

        deadline = (
            time.monotonic()
            + timeout
        )

        url = (
            f"http://127.0.0.1:"
            f"{runtime.port}/health"
        )

        last_error: Optional[str] = None

        while time.monotonic() < deadline:
            if (
                runtime.process is None
                or runtime.process.poll()
                is not None
            ):
                code = (
                    runtime.process.returncode
                    if runtime.process is not None
                    else None
                )

                raise RuntimeError(
                    f"llama-server runtime "
                    f"{runtime.index} exited "
                    f"before readiness "
                    f"(code={code})"
                )

            try:
                with urllib.request.urlopen(
                    url,
                    timeout=2,
                ) as response:
                    if 200 <= response.status < 300:
                        return

            except urllib.error.HTTPError as exc:
                # llama-server may answer 503 while model loading.
                last_error = (
                    f"HTTP {exc.code}"
                )

            except Exception as exc:
                last_error = str(exc)

            time.sleep(
                0.4
            )

        raise TimeoutError(
            f"Runtime {runtime.index} "
            f"on port {runtime.port} "
            f"not ready after {timeout}s"
            + (
                f": {last_error}"
                if last_error
                else ""
            )
        )

    def stop(self) -> None:
        for runtime in list(
            self.runtimes
        ):
            try:
                runtime.stop()
            except Exception:
                pass

        self.runtimes.clear()
        self.admitted_n = 0
