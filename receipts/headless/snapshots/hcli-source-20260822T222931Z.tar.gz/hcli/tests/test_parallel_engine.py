from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from tools.haider.hcli.engine import Engine
from tools.haider.hcli.events import EventBus
from tools.haider.hcli.goal import GoalCompiler
from tools.haider.hcli.runtime import Runtime, RuntimePool
from tools.haider.hcli.workspace import Workspace


class TestParallelEngine(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tmpdir.name)
        self.workspace = Workspace(str(self.root))
        self.bus = EventBus()

        self.pool = MagicMock(spec=RuntimePool)
        self.pool.admitted_n = 3
        self.pool.runtimes = [
            Runtime(index=0, pid=1000 + i, port=8000 + i, model="/m.gguf", active=True)
            for i in range(3)
        ]

        self.engine = Engine(
            workspace=self.workspace,
            event_bus=self.bus,
            runtime_provider=lambda: self.pool,
            runtime_state_provider=lambda: self.pool,
            runtime_count=3,
            model_name="/m.gguf",
        )

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_fixed_hcli_3_keeps_three_physical_descriptors(self):
        self.assertEqual(self.engine.runtime_count, 3)
        self.assertEqual(len(self.pool.runtimes), 3)
        self.assertEqual(self.pool.admitted_n, 3)

    def test_three_independent_ready_workunits_dispatch_concurrently(self):
        calls = []
        lock = threading.Lock()

        def mock_call_model(prompt, evidence, compiled):
            with lock:
                calls.append(time.monotonic())
            time.sleep(0.1)
            return {
                "kind": "answer",
                "content": "ok",
                "operations": [],
                "tests": [],
            }

        self.engine._call_model = mock_call_model

        start = time.monotonic()
        result = self.engine.execute("do three things")
        elapsed = time.monotonic() - start

        self.assertEqual(result["status"], "completed")
        self.assertLess(elapsed, 0.35)

    def test_runtime_indices_differ(self):
        indices = [r.index for r in self.pool.runtimes]
        self.assertEqual(len(set(indices)), 3)

    def test_runtime_ports_differ(self):
        ports = [r.port for r in self.pool.runtimes]
        self.assertEqual(len(set(ports)), 3)

    def test_scheduler_honors_dependencies(self):
        compiler = self.engine.goal_compiler
        compiled = compiler.compile("implement feature")
        self.assertIsNotNone(compiled)

    def test_workers_cannot_race_overlapping_writers(self):
        self.engine._call_model = lambda p, e, c: {
            "kind": "mutation",
            "operations": [
                {"op": "replace", "path": "a.py", "old_text": "x", "new_text": "y"}
            ],
            "tests": [],
        }
        result = self.engine.execute("modify a.py")
        self.assertEqual(result["status"], "completed")

    def test_workers_return_proposals_rather_than_directly_mutating_disk(self):
        self.engine._call_model = lambda p, e, c: {
            "kind": "mutation",
            "operations": [
                {"op": "create", "path": "new.py", "content": "print(1)"}
            ],
            "tests": [],
        }
        result = self.engine.execute("create new.py")
        self.assertEqual(result["status"], "completed")
        self.assertTrue((self.root / "new.py").exists())

    def test_coordinator_combines_compatible_results(self):
        self.engine._call_model = lambda p, e, c: {
            "kind": "answer",
            "content": "combined",
            "operations": [],
            "tests": [],
        }
        result = self.engine.execute("combine")
        self.assertEqual(result["content"], "combined")

    def test_runtime_pool_remains_warm(self):
        self.engine.execute("first")
        self.engine.execute("second")
        self.assertEqual(self.pool.admitted_n, 3)
        self.assertEqual(len(self.pool.runtimes), 3)

    def test_shutdown_leaves_zero_owned_children(self):
        self.engine.execute("run")
        self.pool.stop()
        self.assertEqual(self.pool.admitted_n, 0)
        self.assertEqual(len(self.pool.runtimes), 0)


if __name__ == "__main__":
    unittest.main()