from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

MAX_MUTATION_OPERATIONS = 20


class MutationError(Exception):
    pass


def _snapshot_file(path: str) -> Optional[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return None
    return {"path": path, "content": p.read_text(encoding="utf-8")}


def _restore_file(snapshot: Optional[Dict[str, Any]]) -> None:
    if snapshot is None:
        p = Path(snapshot["path"])
        if p.exists():
            p.unlink()
    else:
        p = Path(snapshot["path"])
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(snapshot["content"], encoding="utf-8")


def _apply_create(path: str, content: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")


def _apply_replace(content: str, old: str, new: str) -> str:
    if old not in content:
        raise MutationError("old_text not found")
    if content.count(old) > 1:
        raise MutationError("old_text not unique")
    return content.replace(old, new, 1)


def _apply_insert(content: str, anchor: str, text: str, mode: str) -> str:
    if anchor not in content:
        raise MutationError("anchor not found")
    if content.count(anchor) > 1:
        raise MutationError("anchor not unique")
    if mode == "insert_before":
        return content.replace(anchor, text + anchor, 1)
    return content.replace(anchor, anchor + text, 1)


def apply_mutation_operations(guard: Any, operations: List[Dict[str, Any]]) -> Dict[str, Any]:
    if len(operations) > MAX_MUTATION_OPERATIONS:
        raise MutationError(f"too many operations: {len(operations)}")
    snapshots: Dict[str, Optional[Dict[str, Any]]] = {}
    changed: List[str] = []
    created: List[str] = []
    for op in operations:
        op_type = op.get("op")
        path = op.get("path")
        if not path:
            raise MutationError("missing path")
        full = guard.resolve(path)
        if op_type == "create":
            if full in snapshots:
                raise MutationError("duplicate create")
            snapshots[full] = _snapshot_file(full)
            _apply_create(full, op.get("content", ""))
            created.append(path)
        elif op_type in ("replace", "insert_before", "insert_after"):
            if full not in snapshots:
                snapshots[full] = _snapshot_file(full)
            p = Path(full)
            if not p.exists():
                raise MutationError("file not found")
            content = p.read_text(encoding="utf-8")
            if op_type == "replace":
                new_content = _apply_replace(content, op.get("old_text", ""), op.get("new_text", ""))
            else:
                new_content = _apply_insert(content, op.get("anchor", ""), op.get("text", ""), op_type)
            p.write_text(new_content, encoding="utf-8")
            if path not in changed:
                changed.append(path)
        else:
            raise MutationError(f"unknown op: {op_type}")
    return {"operation_count": len(operations), "paths": changed + created, "changed": changed, "created": created, "snapshots": snapshots}


def rollback_mutation(mutation_result: Dict[str, Any]) -> None:
    for full_path, snap in mutation_result.get("snapshots", {}).items():
        _restore_file(snap)


def validate_python_syntax(path: str) -> bool:
    try:
        r = subprocess.run([sys.executable, "-m", "py_compile", path], capture_output=True, timeout=10)
        return r.returncode == 0
    except Exception:
        return False


def discover_tests(paths: List[str]) -> List[str]:
    patterns = [r"^test_.*\.py$", r"^.*_test\.py$", r"^.*\.test\.js$", r"^.*\.spec\.js$", r"^.*\.test\.ts$", r"^.*\.spec\.ts$"]
    return [p for p in paths if any(re.match(pat, os.path.basename(p)) for pat in patterns)]


def build_validation_plan(changed: List[str], created: List[str]) -> Dict[str, Any]:
    all_paths = changed + created
    return {
        "syntax_checks": [p for p in all_paths if p.endswith(".py")],
        "tests": discover_tests(all_paths),
        "commands": [["python", "-m", "pytest", "-x"]] if any(p.endswith(".py") for p in all_paths) else [],
    }


def run_validation(plan: Dict[str, Any], workspace_root: str) -> Dict[str, Any]:
    result = {"syntax_ok": True, "tests_ok": True, "commands_ok": True, "details": []}
    for p in plan.get("syntax_checks", []):
        if not validate_python_syntax(os.path.join(workspace_root, p)):
            result["syntax_ok"] = False
            result["details"].append(f"syntax fail: {p}")
    for cmd in plan.get("commands", []):
        try:
            proc = subprocess.run(cmd, cwd=workspace_root, capture_output=True, timeout=60)
            if proc.returncode != 0:
                result["commands_ok"] = False
                result["details"].append(f"cmd fail: {' '.join(cmd)}")
        except Exception as e:
            result["commands_ok"] = False
            result["details"].append(f"cmd error: {e}")
    return result