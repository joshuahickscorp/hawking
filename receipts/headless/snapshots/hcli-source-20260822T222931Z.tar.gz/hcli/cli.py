from __future__ import annotations

import argparse
import os
import sys
from typing import List, Optional


def parse_haider_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="hcli",
        description="HCLI — autonomous local model engineering",
    )
    parser.add_argument("n_or_prompt", nargs="?", type=str, default=None,
                        help="Number of runtimes (1-8) or immediate mission prompt")
    parser.add_argument("prompt", nargs="?", type=str, default=None,
                        help="Immediate mission prompt (when N is supplied positionally)")
    parser.add_argument("--task", type=str, default=None, help="(legacy) mission text")
    parser.add_argument("--task-file", type=str, default=None, help="(legacy) path to mission file")
    parser.add_argument("--model", type=str, default=None, help="Path to GGUF model")
    parser.add_argument("--debug", action="store_true", help="Enable debug output")
    parser.add_argument("--max-turns", type=int, default=10, help="Max observation turns")
    parser.add_argument("--max-cycles", type=int, default=3, help="Max mission cycles")
    parser.add_argument("--workspace", type=str, default=None, help="Workspace root")

    args = parser.parse_args(argv)

    n = 1
    prompt = None

    if args.n_or_prompt is not None:
        try:
            n = int(args.n_or_prompt)
            if n < 1 or n > 8:
                parser.error(f"N must be 1-8, got {n}")
        except ValueError:
            prompt = args.n_or_prompt

    if args.prompt is not None:
        if prompt is not None:
            parser.error("Too many positional arguments")
        prompt = args.prompt

    if args.task:
        if prompt is not None:
            parser.error("Cannot use both positional prompt and --task")
        prompt = args.task
    if args.task_file:
        if prompt is not None:
            parser.error("Cannot use both positional prompt and --task-file")
        try:
            prompt = open(args.task_file).read().strip()
        except Exception as e:
            parser.error(f"Cannot read task file: {e}")

    args.runtime_count = n
    args.prompt = prompt
    args.interactive = prompt is None
    return args


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_haider_args(argv)
    if args.debug:
        print(f"[hcli] args={vars(args)}")
    from .app import App
    app = App(
        workspace=args.workspace or os.getcwd(),
        runtime_count=args.runtime_count,
        model=args.model,
        debug=args.debug,
    )
    return app.run(prompt=args.prompt)
