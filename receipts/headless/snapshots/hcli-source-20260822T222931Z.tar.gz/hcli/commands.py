from __future__ import annotations

from typing import Any, Dict, List, Optional


class CommandHandler:
    def __init__(self, controller: Any):
        self.controller = controller

    def handle(self, line: str) -> Optional[str]:
        line = line.strip()
        if not line.startswith("/"):
            return None
        parts = line.split(None, 1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""
        handler = getattr(self, f"_cmd_{cmd[1:]}", None)
        if handler is None:
            return f"Unknown command: {cmd}"
        return handler(arg)

    def _cmd_help(self, arg: str) -> str:
        return (
            "Commands:\n"
            "  /help - show this help\n"
            "  /status - show session status\n"
            "  /models - list available models\n"
            "  /model - select model\n"
            "  /goal - set active goal\n"
            "  /steer - queue steering instruction\n"
            "  /context - show context summary\n"
            "  /compact - compact context\n"
            "  /clear - clear transcript\n"
            "  /resume - resume session\n"
            "  /exit - exit HCLI"
        )

    def _cmd_status(self, arg: str) -> str:
        session = self.controller.session
        if session is None:
            return "No active session"
        return (
            f"Session: {session.id}\n"
            f"Goal: {session.goal or '(none)'}\n"
            f"Runtimes: {session.runtime_count}\n"
            f"Model: {session.model or '(default)'}\n"
            f"Messages: {len(session.messages)}"
        )

    def _cmd_models(self, arg: str) -> str:
        models = self.controller.list_models()
        if not models:
            return "No models discovered"
        lines = ["Available models:"]
        for m in models:
            marker = "●" if m.get("path") == self.controller.session.model else "  "
            lines.append(f"  {marker} {m.get('name', m.get('path', '?'))}")
        return "\n".join(lines)

    def _cmd_model(self, arg: str) -> str:
        if not arg:
            return "Usage: /model <name-or-path>"
        result = self.controller.select_model(arg)
        if result is None:
            return f"Model not found: {arg}"
        return f"Switched to {result}"

    def _cmd_goal(self, arg: str) -> str:
        if not arg:
            return "Usage: /goal <text>"
        self.controller.set_goal(arg)
        return f"Goal set: {arg}"

    def _cmd_steer(self, arg: str) -> str:
        if not arg:
            return "Usage: /steer <instruction>"
        event = self.controller.queue_steer(arg)
        return f"✓ Steer queued: {event.text}"

    def _cmd_context(self, arg: str) -> str:
        return self.controller.context_summary()

    def _cmd_compact(self, arg: str) -> str:
        self.controller.compact_context()
        return "Context compacted"

    def _cmd_clear(self, arg: str) -> str:
        self.controller.clear_transcript()
        return "Transcript cleared"

    def _cmd_resume(self, arg: str) -> str:
        result = self.controller.resume_session(arg)
        if result is None:
            return "No session to resume"
        return f"Resumed session: {result}"

    def _cmd_exit(self, arg: str) -> str:
        self.controller.request_exit()
        return None