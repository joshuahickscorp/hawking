from __future__ import annotations

from typing import Dict, List


class Context:
    def __init__(self, goal: str = "", constraints: List[str] = None, steering: List[str] = None, validated_facts: List[str] = None):
        self.goal = goal
        self.constraints = constraints or []
        self.steering = steering or []
        self.validated_facts = validated_facts or []

    def to_dict(self) -> Dict:
        return {
            "goal": self.goal,
            "constraints": self.constraints,
            "steering": self.steering,
            "validated_facts": self.validated_facts,
        }

    def compact(self, max_items: int = 5) -> Dict:
        return {
            "goal": self.goal,
            "constraints": self.constraints[-max_items:],
            "steering": self.steering[-max_items:],
            "validated_facts": self.validated_facts[-max_items:],
        }
