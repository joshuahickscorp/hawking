from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class ModelInfo:
    path: str
    name: str
    size_bytes: int
    family: str
    param_class: str
    quantization: str

    @property
    def display_name(self) -> str:
        return f"{self.family} {self.param_class} {self.quantization}"


def _infer_family(filename: str) -> str:
    lower = filename.lower()
    if "qwen" in lower:
        return "Qwen"
    if "llama" in lower:
        return "Llama"
    if "mistral" in lower:
        return "Mistral"
    if "phi" in lower:
        return "Phi"
    if "gemma" in lower:
        return "Gemma"
    if "deepseek" in lower:
        return "DeepSeek"
    return "Unknown"


def _infer_param_class(filename: str) -> str:
    match = re.search(r"(\d+(?:\.\d+)?)\s*b", filename, re.IGNORECASE)
    if match:
        return f"{match.group(1)}B"
    return "?B"


def _infer_quantization(filename: str) -> str:
    match = re.search(r"(q\d+(?:_\w+)?|f16|f32)", filename, re.IGNORECASE)
    if match:
        return match.group(1).upper()
    return "?"


def discover_models(roots: Optional[List[str]] = None) -> List[ModelInfo]:
    if roots is None:
        roots = [os.path.expanduser("~/models")]
    models: List[ModelInfo] = []
    seen: set = set()
    for root in roots:
        if not os.path.isdir(root):
            continue
        for dirpath, _, filenames in os.walk(root):
            for fn in filenames:
                if fn.lower().endswith(".gguf"):
                    full = os.path.realpath(os.path.join(dirpath, fn))
                    if full in seen:
                        continue
                    seen.add(full)
                    try:
                        size = os.path.getsize(full)
                    except OSError:
                        size = 0
                    models.append(ModelInfo(
                        path=full,
                        name=fn,
                        size_bytes=size,
                        family=_infer_family(fn),
                        param_class=_infer_param_class(fn),
                        quantization=_infer_quantization(fn),
                    ))
    return models


def resolve_model(explicit: Optional[str] = None,
                  project_config: Optional[str] = None,
                  global_config: Optional[str] = None,
                  env: Optional[str] = None,
                  discovered: Optional[List[ModelInfo]] = None) -> Optional[ModelInfo]:
    if explicit:
        if os.path.isfile(explicit):
            fn = os.path.basename(explicit)
            return ModelInfo(
                path=os.path.realpath(explicit),
                name=fn,
                size_bytes=os.path.getsize(explicit),
                family=_infer_family(fn),
                param_class=_infer_param_class(fn),
                quantization=_infer_quantization(fn),
            )
        return None
    if project_config and os.path.isfile(project_config):
        fn = os.path.basename(project_config)
        return ModelInfo(
            path=os.path.realpath(project_config),
            name=fn,
            size_bytes=os.path.getsize(project_config),
            family=_infer_family(fn),
            param_class=_infer_param_class(fn),
            quantization=_infer_quantization(fn),
        )
    if global_config and os.path.isfile(global_config):
        fn = os.path.basename(global_config)
        return ModelInfo(
            path=os.path.realpath(global_config),
            name=fn,
            size_bytes=os.path.getsize(global_config),
            family=_infer_family(fn),
            param_class=_infer_param_class(fn),
            quantization=_infer_quantization(fn),
        )
    if env and os.path.isfile(env):
        fn = os.path.basename(env)
        return ModelInfo(
            path=os.path.realpath(env),
            name=fn,
            size_bytes=os.path.getsize(env),
            family=_infer_family(fn),
            param_class=_infer_param_class(fn),
            quantization=_infer_quantization(fn),
        )
    if discovered is None:
        discovered = discover_models()
    if len(discovered) == 1:
        return discovered[0]
    return None



class ModelRegistry:
    """Deterministic local GGUF inventory and selection facade.

    Discovery never loads a model.  Ambiguous discovery remains ambiguous;
    HCLI does not silently choose one of several installed models.
    """

    def __init__(self, roots: Optional[List[str]] = None) -> None:
        self.roots = list(
            roots
            if roots is not None
            else [os.path.expanduser("~/models")]
        )
        self._models: Optional[List[ModelInfo]] = None
        self.selected: Optional[ModelInfo] = None

    def discover(self, refresh: bool = False) -> List[ModelInfo]:
        if self._models is None or refresh:
            self._models = discover_models(self.roots)

        return list(self._models)

    @property
    def models(self) -> List[ModelInfo]:
        return self.discover()

    def resolve(
        self,
        explicit: Optional[str] = None,
        project_config: Optional[str] = None,
        global_config: Optional[str] = None,
        env: Optional[str] = None,
    ) -> Optional[ModelInfo]:
        info = resolve_model(
            explicit=explicit,
            project_config=project_config,
            global_config=global_config,
            env=env,
            discovered=self.discover(),
        )

        if info is not None:
            self.selected = info

        return info

    def select(self, selector: str) -> Optional[ModelInfo]:
        """Select by 1-based index, exact path, filename, or display name."""

        selector = (selector or "").strip()

        if not selector:
            return self.selected

        models = self.discover()

        try:
            index = int(selector)
        except ValueError:
            index = None

        if index is not None:
            if 1 <= index <= len(models):
                self.selected = models[index - 1]
                return self.selected

            return None

        expanded = os.path.realpath(
            os.path.expanduser(selector)
        )

        for info in models:
            if (
                os.path.realpath(info.path) == expanded
                or info.name == selector
                or info.display_name == selector
            ):
                self.selected = info
                return info

        # Explicit path not under a discovery root is still a valid explicit
        # model selection if it is a real file.
        info = resolve_model(explicit=selector)

        if info is not None:
            self.selected = info

        return info

    def status(self) -> dict:
        models = self.discover()

        return {
            "roots": list(self.roots),
            "count": len(models),
            "selected": (
                self.selected.path
                if self.selected is not None
                else None
            ),
        }
