from __future__ import annotations

import os
from typing import Any, Optional

from .engine import Engine
from .events import EventBus
from .models import ModelInfo, ModelRegistry
from .runtime import RuntimePool
from .workspace import Workspace


class Controller:
    """HCLI product controller and owner of the native Engine."""

    def __init__(
        self,
        workspace: Any,
        runtime_count: int = 1,
        model: Optional[str] = None,
        bus: Any = None,
        registry: Optional[ModelRegistry] = None,
    ) -> None:
        if isinstance(
            workspace,
            Workspace,
        ):
            self.workspace = workspace
        else:
            self.workspace = Workspace(
                os.fspath(workspace)
            )

        self.workspace_root = os.path.realpath(
            os.fspath(
                self.workspace.root
            )
        )

        self.runtime_count = int(
            runtime_count
        )

        if self.runtime_count < 1:
            raise ValueError(
                "runtime_count must be >= 1"
            )

        self.model = model

        self.bus = (
            bus
            if bus is not None
            else EventBus()
        )

        self.registry = (
            registry
            if registry is not None
            else ModelRegistry()
        )

        self.model_info: Optional[
            ModelInfo
        ] = None

        self.runtime_pool: Optional[
            RuntimePool
        ] = None

        self._shutdown = False

        migration_env = (
            os.environ.get(
                "HCLI_MODEL_PATH"
            )
            or os.environ.get(
                "HAIDER_MODEL_PATH"
            )
        )

        self.model_info = self.registry.resolve(
            explicit=model,
            env=migration_env,
        )

        engine_model = (
            self.model_info.path
            if self.model_info is not None
            else model
            or migration_env
            or "local"
        )

        self.engine = Engine(
            workspace=self.workspace,
            event_bus=self.bus,
            runtime_provider=self.ensure_runtime_pool,
            runtime_state_provider=lambda: self.runtime_pool,
            runtime_count=self.runtime_count,
            model_name=engine_model,
        )

    @property
    def model_name(
        self,
    ) -> Optional[str]:
        if self.model_info is None:
            return (
                self.model
                if self.model
                else None
            )

        return self.model_info.display_name

    def _emit(
        self,
        event_type: str,
        payload: Optional[dict] = None,
    ) -> None:
        emit = getattr(
            self.bus,
            "emit",
            None,
        )

        if not callable(emit):
            return

        try:
            emit(
                event_type,
                payload or {},
            )
        except Exception:
            pass

    def status(
        self,
    ) -> dict:
        runtimes = []

        if self.runtime_pool is not None:
            for runtime in (
                self.runtime_pool.runtimes
            ):
                runtimes.append(
                    {
                        "index": runtime.index,
                        "pid": runtime.pid,
                        "port": runtime.port,
                        "active": runtime.active,
                        "model": runtime.model,
                    }
                )

        return {
            "workspace": self.workspace_root,
            "requested_runtimes": self.runtime_count,
            "admitted_runtimes": (
                self.runtime_pool.admitted_n
                if self.runtime_pool is not None
                else 0
            ),
            "model": (
                self.model_info.path
                if self.model_info is not None
                else self.model
            ),
            "model_name": self.model_name,
            "runtimes": runtimes,
            "engine_active": self.engine.active,
            "shutdown": self._shutdown,
        }

    def list_models(
        self,
    ) -> list:
        return self.registry.discover()

    def select_model(
        self,
        selector: str,
    ) -> bool:
        selected = self.registry.select(
            selector
        )

        if selected is None:
            self._emit(
                "warning",
                {
                    "message": (
                        f"Model not found: "
                        f"{selector}"
                    )
                },
            )

            return False

        if self.runtime_pool is not None:
            self.runtime_pool.stop()
            self.runtime_pool = None

        self.model_info = selected
        self.model = selected.path
        self.engine.model_name = (
            selected.path
        )

        self._emit(
            "model_switching",
            {
                "model": selected.path,
                "display_name": (
                    selected.display_name
                ),
            },
        )

        return True

    def ensure_runtime_pool(
        self,
    ) -> RuntimePool:
        if self._shutdown:
            raise RuntimeError(
                "Controller is shut down"
            )

        model_path = (
            self.model_info.path
            if self.model_info is not None
            else os.environ.get(
                "HCLI_MODEL_PATH"
            )
            or os.environ.get(
                "HAIDER_MODEL_PATH"
            )
        )

        if not model_path:
            raise RuntimeError(
                "No model selected. "
                "Use /models or /model <number|path>."
            )

        if self.runtime_pool is None:
            pool = RuntimePool(
                model_path,
                requested_n=self.runtime_count,
            )

            self._emit(
                "runtime_loading",
                {
                    "requested": (
                        self.runtime_count
                    ),
                    "model": model_path,
                },
            )

            try:
                pool.start()
            except Exception:
                pool.stop()
                raise

            self.runtime_pool = pool
            self.engine.model_name = model_path

            self._emit(
                "runtime_ready",
                {
                    "requested": (
                        self.runtime_count
                    ),
                    "admitted": (
                        pool.admitted_n
                    ),
                    "runtimes": [
                        {
                            "index": (
                                runtime.index
                            ),
                            "pid": runtime.pid,
                            "port": runtime.port,
                        }
                        for runtime
                        in pool.runtimes
                    ],
                },
            )

        return self.runtime_pool

    def execute(
        self,
        prompt: str,
    ) -> dict:
        prompt = (
            prompt
            or ""
        ).strip()

        if not prompt:
            return {
                "kind": "answer",
                "content": "",
                "operations": [],
                "tests": [],
                "status": "completed",
            }

        return self.engine.execute(
            prompt
        )

    def cancel(
        self,
    ) -> None:
        self.engine.cancel()

    def handle_command(
        self,
        text: str,
    ) -> Any:
        text = (
            text
            or ""
        ).strip()

        if not text:
            return None

        command, _, rest = text.partition(
            " "
        )

        rest = rest.strip()

        if command == "/status":
            status = self.status()

            self._emit(
                "final_response",
                {
                    "content": (
                        "workspace: "
                        f"{status['workspace']}\n"
                        "model: "
                        f"{status['model_name'] or 'not selected'}\n"
                        "runtimes: "
                        f"{status['admitted_runtimes']}/"
                        f"{status['requested_runtimes']}\n"
                        "engine: "
                        f"{'working' if status['engine_active'] else 'idle'}"
                    )
                },
            )

            return status

        if command == "/models":
            models = self.list_models()

            if models:
                content = "\n".join(
                    (
                        f"{index}. "
                        f"{info.display_name}  "
                        f"{info.path}"
                    )
                    for index, info
                    in enumerate(
                        models,
                        start=1,
                    )
                )
            else:
                content = (
                    "No local GGUF models "
                    "discovered."
                )

            self._emit(
                "final_response",
                {
                    "content": content,
                },
            )

            return models

        if command == "/model":
            if not rest:
                return self.handle_command(
                    "/models"
                )

            ok = self.select_model(
                rest
            )

            if ok:
                self._emit(
                    "final_response",
                    {
                        "content": (
                            "Selected model: "
                            f"{self.model_name}"
                        )
                    },
                )

            return ok

        if command in (
            "/cancel",
            "/stop",
        ):
            self.cancel()

            self._emit(
                "final_response",
                {
                    "content": (
                        "Cancellation requested."
                    )
                },
            )

            return True

        if command in (
            "/exit",
            "/quit",
        ):
            self.shutdown()
            return False

        self._emit(
            "warning",
            {
                "message": (
                    "Command boundary not "
                    f"connected yet: {command}"
                )
            },
        )

        return None

    def shutdown(
        self,
    ) -> None:
        if self._shutdown:
            return

        if self.runtime_pool is not None:
            self.runtime_pool.stop()
            self.runtime_pool = None

        self._shutdown = True

        self._emit(
            "session_stopped",
            {},
        )
