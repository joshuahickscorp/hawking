from __future__ import annotations

from typing import Dict, List, Optional

from .workunit import WorkUnit, identify_ready, assign_ready, transition_status


class Scheduler:
    def __init__(self, units: Dict[str, WorkUnit], runtime_count: int) -> None:
        self.units = units
        self.runtime_count = runtime_count

    def dispatch(self) -> List[tuple]:
        ready = identify_ready(self.units)
        return assign_ready(ready, self.runtime_count)

    def complete(self, wu_id: str) -> None:
        wu = self.units.get(wu_id)
        if wu:
            transition_status(wu, "completed")
            wu.assigned_runtime = None

    def fail(self, wu_id: str) -> None:
        wu = self.units.get(wu_id)
        if wu:
            transition_status(wu, "failed")
            wu.assigned_runtime = None

    def is_done(self) -> bool:
        return all(u.status in ("completed", "failed") for u in self.units.values())
