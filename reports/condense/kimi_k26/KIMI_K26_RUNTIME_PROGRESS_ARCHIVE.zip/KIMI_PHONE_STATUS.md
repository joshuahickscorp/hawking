# Kimi K2.6 Doctor Prime

- State: **MONITOR** (RUNNING)
- Running: PID `73361`, process group `73361`
- Lease live: `True`; heartbeat age: `0.9338171482086182` s
- Source: `KIMI_DOWNLOAD_COMPLETE`
- Progress: P0 sealed; P1/P5 F1 bracket preflight advancing
- Download throughput/state: complete
- ETA: done
- Free disk: 40.6 GiB
- Hard disk floor/headroom: 5.0 / 35.6 GiB
- Available memory estimate: 55.1 GiB
- Swap used: 0.3 GiB (16 GiB guard)
- Current file/layer: `P1/P5 F1 representation bracket preflight advancing`
- Sealed/failed checkpoints: 90/0
- Best candidate / complete BPW: `P0_OFFICIAL_PARENT_REFERENCE` / `None`
- Next action: monitor the next advancing experiment
- Exact blocker: `none`
- Last Telegram: `{'checkpoint_id': 'controller:started', 'delivered_at': '2026-07-21T18:56:31Z', 'seal_sha256': '16172e087f8b0332da1f32d4f1a94e5734294b8b90753643908913cc8f0bc800'}`

Control from the Hawking repository:

```text
python3 tools/kimi_k26_campaign.py status
python3 tools/kimi_k26_campaign.py pause-after-checkpoint
python3 tools/kimi_k26_campaign.py resume
python3 tools/kimi_k26_campaign.py stop
```
